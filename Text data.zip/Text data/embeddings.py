import torch
from transformers import BertTokenizer, BertModel
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import umap

# Load Pretrained BERT Model & Tokenizer
model_name = "bert-base-uncased"  # Change to "bert-base-cased" if using cased text
tokenizer = BertTokenizer.from_pretrained(model_name)
model = BertModel.from_pretrained(model_name)

# Read cleaned text
with open("cleaned_text.txt", "r", encoding="utf-8") as f:
    words = f.read().split()  # Tokenize into words

# Remove duplicates (only unique words for visualization)
unique_words = list(set(words))[:200]  # Limiting to 200 words for clarity

# Generate BERT embeddings
def get_bert_embedding(word):
    tokens = tokenizer(word, return_tensors="pt", padding=True, truncation=True)
    with torch.no_grad():
        outputs = model(**tokens)
    return outputs.last_hidden_state.mean(dim=1).squeeze().numpy()  # Mean pooling

# Compute embeddings for all words
embeddings = np.array([get_bert_embedding(word) for word in unique_words])

# Reduce dimensions for visualization
def reduce_dimensions(embeddings, method="tsne"):
    if method == "pca":
        reducer = PCA(n_components=2)
    elif method == "tsne":
        reducer = TSNE(n_components=2, perplexity=30, random_state=42)
    elif method == "umap":
        reducer = umap.UMAP(n_components=2, random_state=42)
    return reducer.fit_transform(embeddings)

# Choose method: "pca", "tsne", or "umap"
reduced_embeddings = reduce_dimensions(embeddings, method="tsne")

# Plot Embeddings
plt.figure(figsize=(10, 7))
plt.scatter(reduced_embeddings[:, 0], reduced_embeddings[:, 1], alpha=0.6)

# Annotate words
for i, word in enumerate(unique_words):
    plt.annotate(word, (reduced_embeddings[i, 0], reduced_embeddings[i, 1]), fontsize=9, alpha=0.7)

plt.title("BERT Word Embeddings Visualization (t-SNE)")
plt.xlabel("Dimension 1")
plt.ylabel("Dimension 2")
plt.show()
